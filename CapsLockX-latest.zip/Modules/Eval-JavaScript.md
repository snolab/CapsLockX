﻿# JavaScript 计算 (建议安装 NodeJS )

| 作用于 | 按键          | 效果                                   |
| ------ | ------------- | -------------------------------------- |
| 全局   | CapsLockX + - | 计算当前选区 JavaScript 表达式，并替换 |
| 全局   | CapsLockX + = | 计算当前选区 JavaScript 表达式，并替换 |