https://github.com/marius-sucan/AHK-GDIp-Library-Compilation
