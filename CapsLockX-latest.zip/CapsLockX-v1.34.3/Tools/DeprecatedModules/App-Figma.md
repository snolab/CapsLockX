﻿# Figma Enhanced

Use Alt+HJKL to navigate, switch focus, zoom in and out in figma.
使用 Alt+HJKL 在 figma 中导航，切換焦点，縮放。

## 常用功能/特性

## 说明

| 模式             | Figma Enhanced | 说明                    |
| ---------------- | :------------: | ----------------------- |
| Figma in browser |      `k`       | ↑ 切換元素 Prev Element |
| Figma in browser |      `j`       | ↓ 切換元素 Next Element |
| Figma in browser |      `h`       | ← 切換層級 Level parent |
| Figma in browser |      `l`       | → 切換層級 Level child  |
