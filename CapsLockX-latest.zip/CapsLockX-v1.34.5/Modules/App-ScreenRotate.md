# Screen Rotate

使用方法

1. OneNote 2016 打开一个窗口，标题写成这样 "剪贴板收集"。
2. 然后再用 Ctrl + C 复制东西的时候就会自动记到 OneNote 里
3. 如图
   ![插件-OneNote剪贴板收集器.gif](./插件-OneNote剪贴板收集器.gif)
