# 媒体键模块

| 作用于 | 媒体键模块        | 说明                                        |
| ------ | ----------------- | ------------------------------------------- |
| 全局   | `CapsLockX + F1`  | 打开：我的电脑                              |
| 全局   | `CapsLockX + F2`  | 打开：计算器                                |
| 全局   | `CapsLockX + F3`  | 打开：浏览器主页                            |
| 全局   | `CapsLockX + F4`  | 打开：媒体库（默认是 Windows Media Player） |
| 全局   | `CapsLockX + F5`  | 播放：暂停/播放                             |
| 全局   | `CapsLockX + F6`  | 播放：上一首                                |
| 全局   | `CapsLockX + F7`  | 播放：下一首                                |
| 全局   | `CapsLockX + F8`  | 播放：停止                                  |
| 全局   | `CapsLockX + F9`  | 音量加                                      |
| 全局   | `CapsLockX + F10` | 音量减                                      |
| 全局   | `CapsLockX + F11` | 静音                                        |
